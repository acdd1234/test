package acdd.shopping;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class TestShopping {
	
	static List <Shop> shops = Arrays.asList(new Shop ("BestPrice"), new Shop ("LetsSaveBig"), 
			new Shop ("MyFavoriteShop"), new Shop ("BuyItAll"));

	
	public static List <String> findPrices (String product) {
		
		return shops.stream().map(shop -> String.format("%s price is %s", shop.getName(), shop.getPrice(product))).collect(Collectors.toList());
		
	}
	
	public static List <String> findPricesInParallel (String product) {
		
		return shops.parallelStream().map(shop -> String.format("%s price is %s", shop.getName(), shop.getPrice(product))).collect(Collectors.toList());
		
	}
	
	private final Executor executor = Executors.newFixedThreadPool(Math.min(shops.size(), 100),
			
			new ThreadFactory () {  public Thread newThread (Runnable r) {
				Thread t = new Thread(r);
				t.setDaemon(true);
				return t;
			}
		
	});
			
			
	
	public static List <String> findPricesInParallelAnAsync (String product) {
		
		List <CompletableFuture<String>> priceFutures = shops.stream().map(shop -> CompletableFuture.supplyAsync(()  -> shop.getName() + "price is" + shop.getPrice(product))).collect(Collectors.toList());
		
		return priceFutures.stream().map(CompletableFuture::join).collect(Collectors.toList());
		
	}
	
	public static List<String> findPricesWithDiscountService (String product) {
		
		//return shops.stream().map(shop -> shop.getPrice(product)).map(Quote::parse).map(Discount::applyDiscount).collect(Collectors.toList());
		
		return shops.stream()
				.map(shop -> shop.getPrice(product)) 
				.map(Quote::parse) 
				.map(Discount::applyDiscount) 
				.collect(Collectors.toList());
	}
	
	
	public static List<String>findPricesComposeSyncAndAsync (String product) {
		List<CompletableFuture<String>> priceFutures =
				shops.stream()
				.map(shop -> CompletableFuture.supplyAsync( 
				() -> shop.getPrice(product)))
				.map(future -> future.thenApply(Quote::parse)) 
				.map(future -> future.thenCompose(quote -> 
				CompletableFuture.supplyAsync(
				() -> Discount.applyDiscount(quote))))
				.collect(Collectors.toList());
		
		return priceFutures.stream().map(CompletableFuture::join).collect(Collectors.toList());
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		long start1 = System.nanoTime();
		
		System.out.println(findPrices("myPhone27s"));
		
		long duration1 = ((System.nanoTime() - start1)/1_000_000);
		System.out.println("Done in " + duration1 + " msecs");
		
		
		long start2 = System.nanoTime();
		
		System.out.println(findPricesInParallel("myPhone27s"));
		
		long duration2 = ((System.nanoTime() - start2)/1_000_000);
		System.out.println("Parallel Done in " + duration2 + " msecs");
		
		
		long start3 = System.nanoTime();
		
		System.out.println(findPricesInParallel("myPhone27s"));
		
		long duration3 = ((System.nanoTime() - start3)/1_000_000);
		System.out.println("Async Parallel Done in " + duration3 + " msecs");
		
		
		System.out.println(Runtime.getRuntime ().availableProcessors());


		long start4 = System.nanoTime();
		
		System.out.println(findPricesWithDiscountService("myPhone27s"));
		
		long duration4 = ((System.nanoTime() - start4)/1_000_000);
		System.out.println("Async Parallel Done in " + duration4 + " msecs");
		
		
		long start5 = System.nanoTime();
		
		System.out.println(findPricesComposeSyncAndAsync("myPhone27s"));
		
		long duration5 = ((System.nanoTime() - start5)/1_000_000);
		System.out.println("Async Parallel Done in " + duration5 + " msecs");
		

	}

}
