package acdd.shopping;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

public class Shop {
	
	String name ;
	
	Shop (String name) {
		this.name = name;
	}
	
	String  getName() {
		return name;
	}
	
	Random random = new Random();
	
	public String getPrice (String product) {
		double price = calculatePrice (product);
		Discount.Code code = Discount.Code.values()[random.nextInt(Discount.Code.values().length)];
		return String.format("%s:%.2f:%s", name, price,code);
	}
	
	
	
	public static void delay () {
		try {
			Thread.sleep(1000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
				throw new RuntimeException();
		}
	}
	
	private double calculatePrice(String product) {
		
		delay ();
		return random.nextDouble() * product.charAt(0) +  product.charAt(1);
		
	}
	
	public Future<Double> getPriceAsync(String product) {
		
		CompletableFuture <Double> futurePrice = new CompletableFuture <>();
		
		new Thread (()-> {double price = calculatePrice (product);
							futurePrice.complete(price);
							}
		).start();
		
		
		return futurePrice;
	}
	
	public Future<Double> getPriceAsync2 (String product) {
		return CompletableFuture.supplyAsync(()-> calculatePrice(product));
	}
	


	
	
	
	public static void main (String [] args)  {
		Shop shop =  new Shop("Best Product");
		System.out.println(shop.getPrice("Best"));
		//System.out.println(findPrices("myPhone27s"));
		
	}

}
