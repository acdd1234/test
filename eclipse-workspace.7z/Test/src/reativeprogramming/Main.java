package reativeprogramming;

import java.util.Arrays;
import java.util.concurrent.Flow.*;
import java.util.concurrent.TimeUnit;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import java.util.*;

import io.reactivex.Observable;
public class Main {
	
	/*public static void main( String[] args ) {
		//getTemperatures( "New York" ).subscribe( new TempSubscriber() );
		getCelsiusTemperatures( "New York" ).subscribe( new TempSubscriber() );
	}*/
	
	/*
	public static void main(String[] args) {
		Observable<TempInfo> observable = getTemperature( "New York" ); 
		observable.subscribe( new TempObserver() ); 
		try {
		Thread.sleep(10000L); 
		} catch (InterruptedException e) {
		throw new RuntimeException(e);
		}
		}*/
	
	public static void main(String[] args) {
		Observable<TempInfo> observable = getCelsiusTemperature( "New York", "Chicago", "San Francisco" ); 
		observable.subscribe( new TempObserver() ); 
		try {
		Thread.sleep(10000L); 
		} catch (InterruptedException e) {
		throw new RuntimeException(e);
		}
		}
	
	//Publisher is functional interface and the methode return an implementation of the interface (anonymous function)
	private static Publisher<TempInfo> getTemperatures( String town ) { 
			return subscriber -> subscriber.onSubscribe(
						new TempSubscription( subscriber, town ) );
	}
	
	public static Publisher <TempInfo> getCelsiusTemperatures (String town) {
		
		return subscriber -> {
			TempProcessor  processor = new TempProcessor();
			processor.subscribe(subscriber);
			processor.onSubscribe(new TempSubscription(processor, town));
		};
		
	}
	
	
	public static Observable<TempInfo> getTemperature(String town) {
		return Observable.create(emitter -> 
		Observable.interval(1, TimeUnit.SECONDS)
		.subscribe(i -> {
		//if (!emitter.isDisposed()) { 
			if ( i >= 5 ) { 
					emitter.onComplete();
			} else {
				try {
					emitter.onNext(TempInfo.fetch(town)); 
				} catch (Exception e) {
					emitter.onError(e); 
				}
					}
			//}
		}));
	}
	
	public static  Observable<TempInfo> getCelsiusTemperature(String town) {
		return getTemperature(town).map(temp -> new TempInfo(temp.getTown(), (temp.getTemp() - 32)*5/9));
	}
	public static Observable<TempInfo> getCelsiusTemperature(String... twons ) {
		return Observable.merge(Arrays.stream(twons).map(Main::getCelsiusTemperature).collect(Collectors.toList()));
	}
	
}