package reativeprogramming;

import java.util.concurrent.Flow.Processor;
import java.util.concurrent.Flow.Subscriber;
import java.util.concurrent.Flow.Subscription;

public class TempProcessor  implements Processor<TempInfo, TempInfo> {
	
	private Subscriber <? super TempInfo> subscriber;
	
	@Override
	public void onNext (TempInfo tempInfo) {
		subscriber.onNext(new TempInfo(tempInfo.getTown(), (tempInfo.getTemp() -32)*5/9));
		
	}

	@Override
	public void onComplete() {
		subscriber.onComplete();
		
	}

	@Override
	public void onError(Throwable arg0) {
		// TODO Auto-generated method stub
		subscriber.onError(arg0);
		
	}

	@Override
	public void onSubscribe(Subscription arg0) {
		// TODO Auto-generated method stub
		subscriber.onSubscribe(arg0);
		
	}

	@Override
	public void subscribe(Subscriber<? super TempInfo> subscriber) {
		// TODO Auto-generated method stub
		this.subscriber = subscriber; 
	}
	

}
