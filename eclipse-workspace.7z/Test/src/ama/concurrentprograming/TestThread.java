package ama.concurrentprograming;

import java.io.*;

public class TestThread {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final Args p = new Args (0,0);
		Thread t1 = new Thread( () -> {try {
			Thread.sleep(10000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		p.left = 3;});
		Thread t2 = new Thread (()-> {p.rigth = 1;
		
		try {
			Thread.sleep(10000L);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}});
		t1.start();
		t2.start();
		try {
			t1.join(); 
			t2.join();
			System.out.println(p.left + p.rigth);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
