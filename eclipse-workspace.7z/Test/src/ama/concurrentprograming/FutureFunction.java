package ama.concurrentprograming;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class FutureFunction {

	static ExecutorService  myexec = Executors.newCachedThreadPool();
	
	static Args p = new Args (0,0);
	static Future<Integer> myFunction1 () 
	{
		
		 return  myexec.submit(() -> {p.left = 1; return p.left;});
	}
	
	static Future<Integer> myFunction2 () 
	{
		
		 return  myexec.submit(() -> {p.rigth = 600; return p.rigth;});
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Future <Integer> left = myFunction1();
		Future <Integer> rigth = myFunction2();
		
		try {
			//System.out.println(left.get() + rigth.get());
			System.out.println(rigth.get() + left.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
