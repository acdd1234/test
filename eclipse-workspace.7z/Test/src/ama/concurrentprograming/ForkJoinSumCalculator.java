package ama.concurrentprograming;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.stream.LongStream;

public class ForkJoinSumCalculator extends java.util.concurrent.RecursiveTask<Long>{
	
	
	private final long [] numbers ;
	private final int start;
	private final int end;
	public static long THRESHOLD = 10_100;
	
	public ForkJoinSumCalculator (long [] numbers, int start, int end) {
		this.numbers = numbers;
		this.start = start;
		this.end = end;
	}
	


	@Override
	protected Long compute() {
		// TODO Auto-generated method stub
		
		int length = end - start ;
		if (length <= THRESHOLD) {
			return computeSequentially();
		}
		
		ForkJoinSumCalculator leftTask = new ForkJoinSumCalculator(numbers, start, start + length/2);
		leftTask.fork();

		ForkJoinSumCalculator rigthTask = new ForkJoinSumCalculator(numbers,start + length/2, end);
		Long rigthResult = rigthTask.compute();
		
		Long leftResult = leftTask.join();
		
		return leftResult + rigthResult;
	}
	
	private Long computeSequentially() {

		long sum = 0;
		for (int i = start; i < end ; i++) {
			sum += numbers[i];
		}
		return sum;

	}
	
	
	public static long forkJoinSum(long n)  {
		long [] numbers = LongStream.rangeClosed(1, n).toArray();
		ForkJoinTask<Long> task  = new ForkJoinSumCalculator(numbers, 0, (int) (n-1));
		return new ForkJoinPool().invoke(task);
	}



	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(forkJoinSum(5));
	}

}
