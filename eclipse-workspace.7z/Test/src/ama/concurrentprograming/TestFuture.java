package ama.concurrentprograming;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

public class TestFuture {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Args p = new Args(0,0);
		FutureTask <Integer> f1 = new FutureTask<Integer> (  ()->  {p.left = 4; Thread.sleep(10000L);return p.left;} );
		FutureTask <Integer> f2 = new FutureTask<Integer> ( () -> {p.rigth = 3; return p.rigth;});
		
		
		
		ExecutorService  executor = Executors.newFixedThreadPool(2);
		executor.execute(f1);
		executor.execute(f2);
		
		try {
			System.out.println(f1.get() + f2.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
