package ama.concurrentprograming;

public class Args {
	public int left;
	public int rigth ;
	
	Args (int l, int r) {
		this.left = l;
		this.rigth = r;
	}

}
