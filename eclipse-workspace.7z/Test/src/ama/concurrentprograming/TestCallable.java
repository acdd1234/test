package ama.concurrentprograming;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class TestCallable {
	
	public static void main (String[] args) {
		
		final Args p = new Args (0,0);
		Callable <Integer> c1  = () -> { Thread.sleep(10000L);p.left = 1; return p.left;};
		Callable <Integer> c2 = () -> {p.rigth = 90 ; return p.rigth;};
		
		ExecutorService myexec  = Executors.newCachedThreadPool();
		
		Future<Integer> p1 = myexec.submit(c1);
		Future <Integer> p2 = myexec.submit(c2);
		
		try {
			System.out.println(p1.get() + p2.get());
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
