package ama.concurrentprograming;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class CompletableFutureTest {
	
	
	public static CompletableFuture<Double> getPriceAsync () {
		
		CompletableFuture <Double> futurePrice = new CompletableFuture <>();
		
		
		new Thread (()->  {
			
			double price = 10;
			futurePrice.complete(price);
			
		}).start();;
		
		return futurePrice;
	}
	
	
	public static CompletableFuture<Integer> getPriceAsync2 () {
		return CompletableFuture.supplyAsync(() -> 27);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println(getPriceAsync2 ().get());
		} catch (InterruptedException | ExecutionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
