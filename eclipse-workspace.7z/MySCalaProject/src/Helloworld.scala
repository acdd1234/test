
import scala.collection.immutable.{TreeMap, TreeSet}
//import scala.xml,_

object Helloworld {
  
  
  def main  (args: Array[String]) {
    
    println("Hello world")
    val s: String = "amadou1"
    var  i: Int = 1
    println(i)
    println(s)
    
    val point = new Point (10, 20)
    point.move(30, 10)
    
    val loc = new Location (1,1,1)
    loc.move(1, 1, 10)
  }
  
}