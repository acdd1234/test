package tutorial

object DemoCollection {
  
  
  def main (args:  Array[String] )= {
    
    
    //List
     var fruits : List[String] = List ("apples", "oranges", "pears")
     var nums: List[Int] = List (1,2,3,4)
     var empty : List[Nothing] = List()
     val dim2 : List[List[Int]] = List(List(1,0,0), List(0,1,0))
     
     
     var fruits2= fruits.::("bananes")
     println(fruits.apply(0))
     println(fruits2.apply(0))
       println(fruits2.last)
       
     //Scala Set
       var s: Set[Int] = Set()
       var si: Set[Int] = Set (1,2,3)
       var s2 = Set (1,2,3,4)
       val fruitsSet = Set ("apples","Oranges", "pears", "pears")
       
       println("Head of fruitsSet: " + fruitsSet.head)
        println("Head of fruitsSet: " + fruitsSet.tail)
        
        val fruitsSet2= fruitsSet.+("patates")
        
        println("Head of fruitsSet2: " + fruitsSet2.head)
        println("Head of fruitsSet2: " + fruitsSet2.tail)
        
        //Map
        
        var A: Map[Char, Int] = Map() 
        A += ('I' ->1)
        println("Value I: " + A.get('I').getOrElse(0))
        
        //Tuple
        
        val t = (1,2,3)
        
        val t3 = new Tuple3(1, "Hello", Console)
        t3.productIterator.foreach(i => println("Value = " + i))
        
        var sum = t._1 +  t._2+  t._3
        
        println(sum)
     
     //Option
     
     val capitals = Map("France"->  "Paris")
     
     println ("Capitals Japan: "+ show(capitals.get("Japon")))
     println ("Capitals France: "+ show(capitals.get("France")))
     
  }
  
  def show (x: Option[String]) = x match {
    case Some (s) => s
    case None =>"?"
  }
  
  
}