package tutorial


import java.util.Date
object Demo {
  
  
  def main (args: Array [String]) {
    
    println("Returned Value: " + addInt(5,7))
    println("Returned Value with default: " + addInt2())
    delayed (time());
    printStrings("Hello", "Scala", "Python", "Java")
    println(factorial(0))
    println(factorial(1))
    println(factorial(2))
    println(factorial(3))
    
    
    val date = new Date
    
    val logWithDateBound = log (date, _:String)
    logWithDateBound ("message1")
    Thread.sleep(1000)
    logWithDateBound ("message2")
    Thread.sleep(1000)
    logWithDateBound ("message3")
    
    
    for (i <- 1 to 10) {
      println("Factorial of " + i + ": = " + factorial(i))
    }
    
    //Higth Order functo=ion
    
    println(apply(layout, 10));
    
    //Anonymous function
    println(inc(2))
    println(mul(3,4))
    //Currying function
     val str1:String = "Hello"
     val str2:String = "Scala"
     println("Str1 + str2 = " + strcat(str1)(str2))
     
     var factor = 10
     println("multiplier(1) value= " + multiplier(1))
     println("multipliet(2) value= " + multiplier(2))
  }
  
  
  def addInt (a: Int,  b: Int): Int = {
      var sum : Int = 0;
      sum = a+ b;
      return sum;
    
  }
  
  def addInt2 (a: Int=5,  b: Int=7): Int = {
      var sum : Int = 0;
      sum = a+ b;
      return sum;
    
  }
  
  
  def time () = {
    println("Getting time in seconds");
    System.nanoTime()
  }
  
  def delayed (t: => Long) = {
    println("In delayed method");
    println ("Param: " + t);
  }
  
  //Function with variable argument
  def printStrings (args: String*) = {
    var i: Int = 0
    for (arg <- args) {
      
      println("Arg value[" + i + "] =" + arg);
      i = i+1;
      
    }
  }
    
    //Function Default Parameter Value
    def addIntWithDefault (a:Int = 5, b:Int = 7): Int ={
      var sum: Int = 0
      sum = a+ b
      return sum
    }
  //Nested Function
    def factorial (i: Int): Int = {
      
      def fact (i:Int, accumulator: Int): Int = {
        
        if (i <= 1)
            accumulator
        else
           fact (i-1, i* accumulator)
      }
    
    fact(i,1)
  } 
    
    //Partialled Applied Function
    
    
    def log (date: Date, message: String) = {
      println( date + "--------" + message)
    }
    
    //Partialled function
    
    val date = new Date
    
    val logWithDateBound = log (date, _:String)
    logWithDateBound ("message1")
    Thread.sleep(1000)
    logWithDateBound ("message2")
    Thread.sleep(1000)
    logWithDateBound ("message3")
    
    
    //Recursion Function
    
   def factorial (n: BigInt): BigInt = {
      
      if (n <= 1)
          1
      else
        n*factorial(n-1)
    }
    
    
    //Hiogh-Order Functions
    def apply (f: Int=>String, v:Int) =  f(v)
    def layout [A] (x: A) = "[" + x.toString() + "]"
    
    
    //Anonymous Function
    var inc = (x:Int) => x+1
    var mul = (x: Int, y:Int) => x*y
    //var userDir = () => {System.g
    
    //Currying Function
    def strcat (s1: String)(s2:String) = s1+s2
    
    //Closuer
    var factor = 3
    val multiplier  = (i:Int) => i*factor
     
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}