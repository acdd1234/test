package cuisine

trait RecipeFinder {
  
  def findRecipe(dish: String) : String
  
}