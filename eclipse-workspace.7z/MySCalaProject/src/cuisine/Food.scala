package cuisine

case class Food (var name: String){
  
}