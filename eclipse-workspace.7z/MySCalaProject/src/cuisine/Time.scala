package cuisine

trait Time {
   def getTime (): String
}