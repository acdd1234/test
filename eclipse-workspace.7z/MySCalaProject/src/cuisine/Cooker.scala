package cuisine

trait Cooker {
  def cook (what: String):  Food
}