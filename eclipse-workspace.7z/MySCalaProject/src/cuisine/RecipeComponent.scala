package cuisine

trait RecipeComponent {
  val recipe: RecipeFinder
  
  class RecipeFinderImpl extends RecipeFinder {
    override def findRecipe (dish: String): String = dish match {
      
      case "chips" => "Fry"
      case "fish" => "Clean the fish"
      case _ => throw new RuntimeException (s"${dish} is unknown")
    }
  }
}