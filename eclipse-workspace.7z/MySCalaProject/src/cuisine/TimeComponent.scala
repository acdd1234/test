package cuisine

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

trait TimeComponent {
  val time: Time
  
  class TimeImpl extends Time {
     val formatter = DateTimeFormatter.ofPattern("HH:mm:ss")
     override def getTime (): String = s"The time is: ${LocalDateTime.now().format(formatter)}"
  }
}