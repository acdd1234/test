package creationalpattern

class MysqlClient extends DatabaseClient {
   override protected def connect(): SimpleConnection = new SimpleMysqlConnection
}