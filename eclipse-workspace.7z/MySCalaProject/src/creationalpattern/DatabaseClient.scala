package creationalpattern

abstract class DatabaseClient {
  def executeQuery (query: String): Unit = {
    val connection = connect()
    connection.executeQuery(query)
  }
  
  protected def connect(): SimpleConnection
}