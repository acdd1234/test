package creationalpattern

trait SimpleConnection {
  def getName (): String
  def executeQuery (query: String): Unit
}