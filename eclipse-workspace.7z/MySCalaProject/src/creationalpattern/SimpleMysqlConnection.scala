package creationalpattern

class SimpleMysqlConnection extends SimpleConnection{
  
  override def getName (): String = "SimpleConnection"
  override def executeQuery (query: String) : Unit = {
    System.out.println(s"Executing the query '$query' the MySql way")
  }
  
}