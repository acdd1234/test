package creationalpattern

object Example {
  def main (args: Array[String]): Unit = {
    val clientMySql: DatabaseClient = new MysqlClient
    
    val clientPgSql: DatabaseClient = new PgSqlClient
    clientMySql.executeQuery("SELECT * FROM user")
    clientPgSql.executeQuery("SELECT * FROM employees")
  }
}